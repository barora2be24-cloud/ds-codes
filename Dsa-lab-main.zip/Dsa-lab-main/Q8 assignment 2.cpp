def count_distinct(arr):
    return len(set(arr))

arr = [1, 2, 2, 3, 4, 4, 5]
print("Number of distinct elements:", count_distinct(a
rr))
