def sort_strings(strings):
    return sorted(strings)

print(sort_strings(["banana", "apple", "cherry"
]))
