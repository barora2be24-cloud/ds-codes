def reverse_string(s):
    return s[::-1]

print(reverse_string("Python
"))
